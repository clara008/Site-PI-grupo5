let currentQuestion = 1; 
const totalQuestions = 10; // Total de perguntas no quiz

// Navegar entre as perguntas
function navegarPerguntas(direction) {
    // Esconde a pergunta atual
    document.getElementById(`q${currentQuestion}`).style.display = "none";

    // Atualiza o número da pergunta com base na direção
    currentQuestion += direction;

    
    if (currentQuestion > totalQuestions) {
        // Redireciona para outra página
        window.location.href = "resultado.html";
        return;
    }

    // Controle de visibilidade dos botões
    if (currentQuestion === totalQuestions) {
        document.getElementById("next").textContent = "Finalizar"; 
    } else {
        document.getElementById("next").textContent = "Próxima";
    }

    document.getElementById("prev").style.display = currentQuestion > 1 ? "inline-block" : "none";

    
    document.getElementById(`q${currentQuestion}`).style.display = "block";
}

let acertos = 0;

for (let i = 1; i <= totalQuestions; i++) {
    // Verifica qual resposta foi marcada
    const resposta = document.querySelector(`input[name="q${i}"]:checked`);

    // Se a resposta marcada tem valor 1, conta como acerto
    if (resposta && Number(resposta.value) === 1) {
        acertos++;
    }
}

// Armazena o número de acertos no localStorage
localStorage.setItem("quizAcertos", acertos);

